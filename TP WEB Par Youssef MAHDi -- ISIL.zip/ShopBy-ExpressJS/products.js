const products=[{
    id:1,
    image:'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/e8e530a3-2317-4783-819b-40860281daaf/streakfly-road-racing-shoes-V17qZm.png',
    name:"Men's Sale Shoes",
    price:300
},
{
    id:2,
    image:'https://static.nike.com/a/images/t_PDP_1280_v1/f_auto,q_auto:eco/cc763817-06f5-4d38-927e-0404d1e9198b/air-max-270-womens-shoes-Pgb94t.png',
    name:"Nike Air Max 270",
    price:100
},
{
    id:3,
    image:'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/e8e530a3-2317-4783-819b-40860281daaf/streakfly-road-racing-shoes-V17qZm.png',
    name:"Men's Sale Shoes. Nike SG",
    price:200

}
,{
    id:4,
    image:'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/3c20bb9e-48d2-44e4-bb2a-abe502b11b50/air-max-270-shoes-s1JpCx.png',
    name:"Air Max 270 Shoes. Nike IN",
    price:150
},
{
    id:5,
    image:"https://static.nike.com/a/images/c_limit,w_400,f_auto/t_product_v1/38f6c6c4-e982-408c-9802-75b1cebee467/image.jpg",
    name:"Kids' Shoes",
    price:120
},
{
    id:6,
    image:'https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/23926929-69d8-49a4-be3b-81ba08dc4e26/air-max-2021-se-shoes-xCGnZG.png',
    name:"Men's Sale Shoes. Nike PH",
    price:300
}

]
module.exports=products;