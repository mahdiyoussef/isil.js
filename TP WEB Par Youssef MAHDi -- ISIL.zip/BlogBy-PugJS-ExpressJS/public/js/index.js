// fetch('http://127.0.0.1:3000/posts',{method:'GET'}).then((r)=>{
//     console.log(r.body)
// })